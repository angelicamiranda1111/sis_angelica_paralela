<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../style-form.css">
</head>
<body>
<?php
    require_once('../conexao.php');

   $id = $_POST['id'];

   ##sql para selecionar apens um aluno
   $sql = "SELECT * FROM aluno where id= :id";
   
   # junta o sql a conexao do banco
   $retorno = $conexao->prepare($sql);

   ##diz o paramentro e o tipo  do paramentros
   $retorno->bindParam(':id',$id, PDO::PARAM_INT);

   #executa a estrutura no banco
   $retorno->execute();

  #transforma o retorno em array
   $array_retorno=$retorno->fetch();
   
   ##armazena retorno em variaveis
   $nome = $array_retorno['nome'];
   $idade = $array_retorno['idade'];
   $id = $array_retorno['id'];
   $datanascimento = $array_retorno['datanascimento'];
   $endereco = $array_retorno['endereco'];


?>

    <h1>♡ Alterar Aluno ♡</h1>

    <form class="a" method="POST" action="crudaluno.php">
    <label for="">Nome Aluno</label>
    <input type="text" name="nomealuno" value="<?php echo $nome?>">

    <label for="">Idade</label>
     <input type="number" name="idade" value="<?php echo $idade?>"> 

    <label for="">Data de Nascimento</label>
     <input type="date" name="datanascimento" value="<?php echo $datanascimento?>"> 

    <label for="">Endereço</label>
     <input type="text" name="endereco" value="<?php echo $endereco?>">

     <label for="">Status</label>
     <select name="estatus" id="">
        <option value="ap">Aprovado</option>
        <option value="rep">Reprovado</option>
     </select>

     <input type="hidden" name="id" value="<?php echo $id?>">

    <br><br>

    <input type="submit" name="update" value="ALTERAR">
    </form>

   <p></p>
   
   <button class="button"><a href="listalunos.php">voltar</a></button>

</body>
</html>