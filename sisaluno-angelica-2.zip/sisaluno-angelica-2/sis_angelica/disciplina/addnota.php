<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cadastro disciplina</title>
    <link rel="stylesheet" href="../style-form.css">
</head>
<body>
    <?php
        $id = $_GET['id'];
        $nome = $_GET['nome'];
    ?>
    <h1>♡ Adicionar Notas ♡</h1>

   <form class="a" method="POST" action="cruddisciplina.php">
    <label for="">Nota 1:</label>
    <input type="number" name="nota1">

    <label for="">Nota 2:</label>
     <input type="number" name="nota2">

    <input type="hidden" name="id" value="<?php echo $id?>">
    <input type="hidden" name="nome" value="<?php echo $nome?>">

     <p></p>

    <input type="submit" name="addnota" value="Adicionar Nota">
    </form>

   <p></p>
   
   <button class="button"><a href="listadisciplina.php">voltar</a></button>

</body>
</html>