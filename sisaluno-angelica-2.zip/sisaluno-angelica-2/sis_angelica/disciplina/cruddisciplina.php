<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style-form.css">
    <title>Document</title>
</head>
<body>
<?php
require_once('../conexao.php');

if(isset($_GET["cadastrar"])){
        $nomedisciplina = $_GET["nomedisciplina"];
        $ch = $_GET["ch"];
        $semestre = $_GET["semestre"];
        $idprofessor = $_GET["idprofessor"];
        $nota1 = 0;
        $nota2 = 0;
        $media = 0;

        $sql = "INSERT INTO disciplina(nomedisciplina,ch,semestre,idprofessor, Nota1, Nota2, Media) 
                VALUES('$nomedisciplina','$ch','$semestre','$idprofessor', '$nota1', '$nota2' , '$media')";

        $sqlcombanco = $conexao->prepare($sql);

        if($sqlcombanco->execute())
            {
                echo " <strong>OK!</strong> A disciplina
                $nomedisciplina foi Incluido com sucesso!!!"; 
                echo " <button class='button'><a href='../index.php'>voltar</a></button>";
            }
        }
#######alterar
if(isset($_POST['update'])){

    ##dados recebidos pelo metodo POST
    $nomedisciplina = $_POST["nomedisciplina"];
    $ch = $_POST["ch"];
    $id = $_POST["id"];
    $semestre = $_POST["semestre"];
    $idprofessor = $_POST["idprofessor"];
   
      ##codigo sql
    $sql = "UPDATE  disciplina SET nomedisciplina  = :nomedisciplina, ch = :ch, semestre = :semestre, idprofessor = :idprofessor WHERE id= :id ";
   
    ##junta o codigo sql a conexao do banco
    $stmt = $conexao->prepare($sql);

    ##diz o paramentro e o tipo  do paramentros
    $stmt->bindParam(':id',$id, PDO::PARAM_INT);
    $stmt->bindParam(':nomedisciplina',$nomedisciplina, PDO::PARAM_STR);
    $stmt->bindParam(':ch',$ch, PDO::PARAM_STR);
    $stmt->bindParam(':semestre',$semestre, PDO::PARAM_STR);
    $stmt->bindParam(':idprofessor',$idprofessor, PDO::PARAM_INT);
    $stmt->execute();
 


    if($stmt->execute())
        {
            echo " <strong>OK!</strong> a disciplina
             $nomedisciplina foi Alterado com sucesso!!!"; 

            echo " <button class='button'><a href='index.php'>voltar</a></button>";
        }

}        


##Excluir
if(isset($_GET['excluir'])){
    $id = $_GET['id'];
    $sql ="DELETE FROM `disciplina` WHERE id={$id}";
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
    $stmt = $conexao->prepare($sql);
    $stmt->execute();

    if($stmt->execute())
        {
            echo " <strong>OK!</strong> a disciplina
            $id foi excluido!!!"; 

            echo " <button class='button'><a href='index.php'>voltar</a></button>";
        }

}

if(isset($_POST['addnota'])){

    ##dados recebidos pelo metodo POST
    $id = $_POST["id"];
    $nota1 = $_POST["nota1"];
    $nota2 = $_POST["nota2"];
    $nome = $_POST["nome"];
    $media = ($nota1 + $nota2) / 2;
   
      ##codigo sql
    $sql = "UPDATE  disciplina SET Nota1  = :nota1, Nota2 = :nota2, Media = :media WHERE id= :id ";
   
    ##junta o codigo sql a conexao do banco
    $stmt = $conexao->prepare($sql);

    ##diz o paramentro e o tipo  do paramentros
    $stmt->bindParam(':id',$id, PDO::PARAM_INT);
    $stmt->bindParam(':nota1',$nota1, PDO::PARAM_INT);
    $stmt->bindParam(':nota2',$nota2, PDO::PARAM_INT);
    $stmt->bindParam(':media', $media, PDO::PARAM_INT);
    $stmt->execute();
 


    if($stmt->execute())
        {
            echo " <strong>OK!</strong> A nota da disciplina $nome foi adicionada com sucesso!!!"; 

            echo " <button class='button'><a href='listadisciplina.php'>voltar</a></button>";
        }

}

if(isset($_POST['altnota'])){

    ##dados recebidos pelo metodo POST
    $id = $_POST["id"];
    $nota1 = $_POST["nota1"];
    $nota2 = $_POST["nota2"];
    $nome = $_POST["nome"];
    $media = ($nota1 + $nota2) / 2;
   
      ##codigo sql
    $sql = "UPDATE  disciplina SET Nota1  = :nota1, Nota2 = :nota2, Media = :media WHERE id= :id ";
   
    ##junta o codigo sql a conexao do banco
    $stmt = $conexao->prepare($sql);

    ##diz o paramentro e o tipo  do paramentros
    $stmt->bindParam(':id',$id, PDO::PARAM_INT);
    $stmt->bindParam(':nota1',$nota1, PDO::PARAM_INT);
    $stmt->bindParam(':nota2',$nota2, PDO::PARAM_INT);
    $stmt->bindParam(':media', $media, PDO::PARAM_INT);
    $stmt->execute();
 


    if($stmt->execute())
        {
            echo " <strong>OK!</strong> A nota da disciplina $nome foi alterada com sucesso!!!"; 

            echo " <button class='button'><a href='listadisciplina.php'>voltar</a></button>";
        }

}

        
?>
</body>
</html>