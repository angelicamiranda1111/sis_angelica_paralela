<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style-form.css">
    <title>Lista de disciplinas</title>
</head>
<body>
    <?php 
  require_once('../conexao.php');
   
  $retorno = $conexao->prepare('SELECT * FROM disciplina');
  $retorno -> execute();

?>
<h1>♡ Lista de Disciplinas ♡</h1>
<div class=tres>
<table> 
            <thead>
                <tr>
          
                    <th>ID</th>
                    <th>NOME DISCIPLINA</th>
                    <th>CH</th>
                    <th>SEMESTRE</th>
                    <th>IDPROFESSOR</th>
                    <th>&nbsp</th>
                    <th>&nbsp</th>
                    <th>NOTA 01</th>
                    <th>NOTA 02</th>
                    <th>MEDIA</th>
                    <th>&nbsp</th>
                    <th>&nbsp</th>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <?php foreach($retorno->fetchall() as $value) { ?>
                        <tr>
                            <td> <?php echo $value['id'] ?>      </td> 
                            <td> <?php echo $value['nomedisciplina']?>     </td> 
                            <td> <?php echo $value['ch']?>    </td> 
                            <td> <?php echo $value['semestre']?> </td> 
                            <td> <?php echo $value['idprofessor']?> </td>

                            <td>
                               <form method="POST" action="altdisciplina.php">
                                        <input name="id" type="hidden" value="<?php echo $value['id'];?>"/>
                                        <button name="alterar"  type="submit">Alterar</button>
                                </form>

                             </td> 

                             <td>
                               <form method="GET" action="cruddisciplina.php">
                                        <input name="id" type="hidden" value="<?php echo $value['id'];?>"/>
                                        <button name="excluir"  type="submit">Excluir</button>
                                </form>
                             </td>

                            <td> <?php echo $value['Nota1']?> </td> 
                            <td> <?php echo $value['Nota2']?> </td> 
                            <td> <?php echo $value['Media']?> </td> 

                             <td>
                               <form method="GET" action="addnota.php">
                                        <input name="id" type="hidden" value="<?php echo $value['id'];?>"/>
                                        <input name="nome" type="hidden" value="<?php echo $value['nomedisciplina'];?>"/>
                                        <button class="nota" name="altnota"  type="submit">Add Nota</button>
                                </form>
                             </td>

                             <td>
                               <form method="GET" action="altnota.php">
                                        <input name="id" type="hidden" value="<?php echo $value['id'];?>"/>
                                        <input name="nome" type="hidden" value="<?php echo $value['nomedisciplina'];?>"/>
                                        <input name="nota1" type="hidden" value="<?php echo $value['Nota1'];?>"/>
                                        <input name="nota2" type="hidden" value="<?php echo $value['Nota2'];?>"/>
                                        <button class="nota" name="altnota"  type="submit">Alterar Nota</button>
                                </form>
                             </td>
                      </tr>
                    <?php  }  ?> 
                 </tr>
            </tbody>
        </table>
</div>

<?php         
   echo "<br><br><button class='button'><a href='../index.php'>voltar</a></button>";
?>
</body>
</html>