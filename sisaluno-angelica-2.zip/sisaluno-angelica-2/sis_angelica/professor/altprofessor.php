<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style-form.css">
    <title>Alterar Professor</title>
</head>
<body>

<?php
    require_once('../conexao.php');

   $id = $_POST['id'];

   ##sql para selecionar apens um aluno
   $sql = "SELECT * FROM professor where id= :id";
   
   # junta o sql a conexao do banco
   $retorno = $conexao->prepare($sql);

   ##diz o paramentro e o tipo  do paramentros
   $retorno->bindParam(':id',$id, PDO::PARAM_INT);

   #executa a estrutura no banco
   $retorno->execute();

  #transforma o retorno em array
   $array_retorno=$retorno->fetch();
   
   ##armazena retorno em variaveis
   $nomeprofessor = $array_retorno['nome'];
   $idade = $array_retorno['idade'];
   $id = $array_retorno['id'];
   $cpf = $array_retorno['cpf'];
   $datanascimento = $array_retorno['datanascimento'];
   $endereco = $array_retorno['endereco'];
   $estatus = $array_retorno['estatus'];


?>
<h1>♡ Alterar Professor ♡</h1>

  <form class="a" method="POST" action="crudprofessor.php">

     <label for="">Nome Professor</label>
     <input type="text" name="nomeprofessor" value="<?php echo $nomeprofessor?>">

     <label for="idade">Idade</label>
     <input type="text" name="idade" value="<?php echo $idade?>"> 

     <label for="cpf">CPF</label>
     <input type="text" name="cpf" value="<?php echo $cpf?>">

     <label for="endereco">Endereço</label>
     <input type="text" name="endereco" value="<?php echo $endereco?>"> 

     <label for="datanascimento">Data de Nascimento</label>
     <input type="date" name="datanascimento" value="<?php echo $datanascimento?>"> 

     <label for="estatus"> Estatus:
        <label for="">
          <input type="radio" name="estatus" value="1" checked>
          Ativo
        </label>
        <label for="">
          <input type="radio" name="estatus" value="0">
          Desativo
        </label>
        
      <input type="hidden" value="<?php echo $id?>" name="id">

        <p></p>

     <input type="submit" name="update" value="ALTERAR">

     <p></p>

     <button class="button"><a href="index.php">voltar</a></button>

  </form>

</body>
</html>